import java.util.Random;
import java.util.Scanner;

public class SumaPrefija {
    private static Random scanner;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números: ");
        int n = scanner.nextInt();

        int[] numbers = new int[n];

        System.out.println("Ingrese los números:");
        for (int i = 0; i < n; i++) {
            numbers[i] = scanner.nextInt();
        }

        scanner.close();

        // Calcular la suma prefija
        int prefixSum = 0;
        for (int i = 0; i < numbers.length; i++) {
            prefixSum += numbers[i];
            System.out.println(numbers[i] + ", " + prefixSum);
        }


    }
}
