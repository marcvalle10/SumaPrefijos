import java.util.Scanner;

public class SumaPrefijaConX {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el valor objetivo (x): ");
        int targetSum = scanner.nextInt();

        System.out.print("Ingrese la cantidad de números: ");
        int n = scanner.nextInt();

        int[] numbers = new int[n];

        System.out.println("Ingrese los números:");
        for (int i = 0; i < n; i++) {
            numbers[i] = scanner.nextInt();
        }

        scanner.close();

        // Calcular la suma prefija
        int prefixSum = 0;
        for (int i = 0; i < numbers.length; i++) {
            prefixSum += numbers[i];
            System.out.println(numbers[i] + ", " + prefixSum);
        }

        // Comprobar si existen dos elementos que sumen al valor objetivo
        for (int i = 0; i < numbers.length - 1; i++) {
            for (int j = i + 1; j < numbers.length; j++) {
                if (numbers[i] + numbers[j] == targetSum) {
                    System.out.println("Si");
                    return;
                }
            }
        }

        System.out.println("No");
    }
}
